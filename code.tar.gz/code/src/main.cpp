#include "../inc/main.h"

int main()
{
	printFib(5);
	return 0;
}
